#!/bin/sh
DIR=$(readlink -f "$0")

echo "Hello from $DIR"
