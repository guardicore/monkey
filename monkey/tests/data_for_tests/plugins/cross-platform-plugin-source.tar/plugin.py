print("Hello cross-platform World!")
