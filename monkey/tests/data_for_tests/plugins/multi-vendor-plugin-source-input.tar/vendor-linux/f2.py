print("This is vendor-linux/f2.py")
