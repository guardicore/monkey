print("This is vendor-windows f1")
