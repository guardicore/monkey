print("This is vendor-linux/f1.py")
