print("Hello multi-vendor World!")
