print("Hello Linux World!")
